import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { useTheme } from 'next-themes';
import { Moon, Sun, Palette, Image as ImageIcon, Save } from 'lucide-react';
import { ImageUpload } from './ImageUpload';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export function AdminSettings() {
  const { theme, setTheme } = useTheme();
  const [backgroundImage, setBackgroundImage] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const fetchSettings = async () => {
      const { data } = await supabase
        .from('site_settings')
        .select('value')
        .eq('key', 'site_background')
        .maybeSingle();
      if (data?.value && typeof data.value === 'object' && 'image_url' in (data.value as any)) {
        setBackgroundImage((data.value as any).image_url || '');
      }
    };
    fetchSettings();
  }, []);

  const handleSaveBackground = async () => {
    setIsSaving(true);
    try {
      const { data: existing } = await supabase
        .from('site_settings')
        .select('id')
        .eq('key', 'site_background')
        .maybeSingle();

      if (existing) {
        await supabase
          .from('site_settings')
          .update({ value: { image_url: backgroundImage } as any })
          .eq('key', 'site_background');
      } else {
        await supabase
          .from('site_settings')
          .insert({ key: 'site_background', value: { image_url: backgroundImage } as any });
      }
      toast.success('Fundo do site guardado!');
    } catch {
      toast.error('Erro ao guardar');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-bold text-foreground">Definições</h1>
        <p className="text-muted-foreground">Configure as preferências da loja</p>
      </div>

      <div className="grid gap-6">
        {/* Theme Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="h-5 w-5 text-primary" />
              Aparência
            </CardTitle>
            <CardDescription>Personalize o tema visual do painel de administração</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {theme === 'dark' ? <Moon className="h-5 w-5 text-primary" /> : <Sun className="h-5 w-5 text-primary" />}
                <div>
                  <Label className="text-base">Modo Escuro</Label>
                  <p className="text-sm text-muted-foreground">Alterne entre o tema claro e escuro</p>
                </div>
              </div>
              <Switch checked={theme === 'dark'} onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setTheme('light')}
                className={`p-4 rounded-xl border-2 transition-all ${theme === 'light' ? 'border-primary ring-2 ring-primary/20' : 'border-border hover:border-primary/50'}`}
              >
                <div className="bg-white rounded-lg p-3 space-y-2 shadow-sm">
                  <div className="h-2 w-16 bg-gray-200 rounded" />
                  <div className="h-2 w-24 bg-gray-100 rounded" />
                  <div className="h-6 w-full bg-rose-100 rounded" />
                </div>
                <p className="text-sm font-medium mt-2">Claro</p>
              </button>
              <button
                onClick={() => setTheme('dark')}
                className={`p-4 rounded-xl border-2 transition-all ${theme === 'dark' ? 'border-primary ring-2 ring-primary/20' : 'border-border hover:border-primary/50'}`}
              >
                <div className="bg-gray-900 rounded-lg p-3 space-y-2 shadow-sm">
                  <div className="h-2 w-16 bg-gray-700 rounded" />
                  <div className="h-2 w-24 bg-gray-800 rounded" />
                  <div className="h-6 w-full bg-rose-900/50 rounded" />
                </div>
                <p className="text-sm font-medium mt-2">Escuro</p>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Background Image */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ImageIcon className="h-5 w-5 text-primary" />
              Imagem de Fundo do Site
            </CardTitle>
            <CardDescription>Escolha uma imagem de fundo para o site (hero section)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <ImageUpload
              value={backgroundImage}
              onChange={setBackgroundImage}
              folder="site"
              label="Imagem de Fundo"
            />
            <Button onClick={handleSaveBackground} disabled={isSaving} className="w-full">
              <Save className="h-4 w-4 mr-2" />
              {isSaving ? 'A guardar...' : 'Guardar Fundo'}
            </Button>
          </CardContent>
        </Card>

        {/* Store Info */}
        <Card>
          <CardHeader>
            <CardTitle>Informações da Loja</CardTitle>
            <CardDescription>Dados gerais da loja online</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-muted-foreground text-sm">Nome da Loja</Label>
                <p className="font-medium">FIO & ALMA STUDIO</p>
              </div>
              <div>
                <Label className="text-muted-foreground text-sm">Moeda</Label>
                <p className="font-medium">EUR (€)</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Future features */}
        <Card>
          <CardHeader>
            <CardTitle>Funcionalidades em Desenvolvimento</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary/50" />
                Exportação de contabilidade para Excel
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary/50" />
                Emissão automática de faturas
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary/50" />
                Emails de confirmação de compra
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary/50" />
                Configurações de envio e pagamento
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
