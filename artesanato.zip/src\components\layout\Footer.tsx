import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Mail, Phone, MapPin, Heart, Download, Smartphone, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { usePWAInstall } from '@/hooks/usePWAInstall';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export function Footer() {
  const { isInstallable, isInstalled, installApp } = usePWAInstall();
  const isInStandaloneMode = typeof window !== 'undefined' && window.matchMedia('(display-mode: standalone)').matches;
  const showInstall = (isInstallable || /iPad|iPhone|iPod/.test(navigator.userAgent)) && !isInstalled && !isInStandaloneMode;
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterLoading, setNewsletterLoading] = useState(false);

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim() || !newsletterEmail.includes('@')) {
      toast.error('Introduza um email válido');
      return;
    }
    setNewsletterLoading(true);
    try {
      const { error } = await supabase
        .from('newsletter_subscribers')
        .insert({ email: newsletterEmail.trim().toLowerCase() });
      if (error) {
        if (error.code === '23505') {
          toast.info('Este email já está subscrito à nossa newsletter!');
        } else {
          throw error;
        }
      } else {
        toast.success('Obrigado! Subscrição efetuada com sucesso 💛');
      }
      setNewsletterEmail('');
    } catch (err) {
      console.error('Newsletter error:', err);
      toast.error('Erro ao subscrever. Tente novamente.');
    } finally {
      setNewsletterLoading(false);
    }
  };

  return (
    <footer className="bg-secondary text-secondary-foreground relative overflow-hidden">
      {/* Decorative thread */}
      <svg className="absolute top-0 left-0 w-full h-8 opacity-20" viewBox="0 0 1200 32" preserveAspectRatio="none">
        <path 
          d="M0,16 Q300,0 600,16 T1200,16" 
          fill="none" 
          stroke="hsl(var(--craft))" 
          strokeWidth="2"
          strokeDasharray="10,5"
        />
      </svg>

      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="space-y-5">
            <div>
              <h3 className="font-script text-3xl text-primary">
                Fio & Alma Studio
              </h3>
              <p className="text-xs tracking-widest text-muted-foreground uppercase mt-1">
                Costura Artesanal
              </p>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Duas artesãs unidas pela paixão da costura tradicional. 
              Cada peça conta uma história, cada ponto é feito com amor.
            </p>
            <div className="flex space-x-3">
              <Button variant="ghost" size="icon" className="hover:text-primary hover:bg-primary/10 rounded-full">
                <Instagram className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-primary hover:bg-primary/10 rounded-full">
                <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
                </svg>
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-primary hover:bg-primary/10 rounded-full">
                <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/>
                </svg>
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-5">
            <h4 className="font-serif font-semibold text-lg flex items-center gap-2">
              <span className="text-craft">✿</span>
              Navegação
            </h4>
            <ul className="space-y-3 text-sm">
              <li>
                <Link to="/products" className="text-muted-foreground hover:text-primary transition-colors inline-flex items-center gap-2">
                  <span className="text-xs text-craft">→</span>
                  Nossa Coleção
                </Link>
              </li>
              <li>
                <Link to="/categories" className="text-muted-foreground hover:text-primary transition-colors inline-flex items-center gap-2">
                  <span className="text-xs text-craft">→</span>
                  Categorias
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-muted-foreground hover:text-primary transition-colors inline-flex items-center gap-2">
                  <span className="text-xs text-craft">→</span>
                  Sobre as Artesãs
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-muted-foreground hover:text-primary transition-colors inline-flex items-center gap-2">
                  <span className="text-xs text-craft">→</span>
                  Contacto
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-5">
            <h4 className="font-serif font-semibold text-lg flex items-center gap-2">
              <span className="text-craft">✿</span>
              Contacto
            </h4>
            <ul className="space-y-4 text-sm">
              <li className="flex items-center space-x-3 text-muted-foreground">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <Mail className="h-4 w-4 text-primary" />
                </div>
                <span>ola@fioealma.pt</span>
              </li>
              <li className="flex items-center space-x-3 text-muted-foreground">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <Phone className="h-4 w-4 text-primary" />
                </div>
                <span>+351 912 345 678</span>
              </li>
              <li className="flex items-center space-x-3 text-muted-foreground">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <MapPin className="h-4 w-4 text-primary" />
                </div>
                <span>Lisboa, Portugal</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div className="space-y-5">
            <h4 className="font-serif font-semibold text-lg flex items-center gap-2">
              <span className="text-craft">✿</span>
              Newsletter
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Receba novidades sobre novas peças e promoções exclusivas.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="flex flex-col space-y-3">
              <Input 
                type="email" 
                placeholder="O seu email"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                className="bg-background/10 border-craft/30 rounded-full focus:border-primary placeholder:text-muted-foreground/50"
                required
              />
              <Button type="submit" className="w-full rounded-full bg-primary hover:bg-primary-hover" disabled={newsletterLoading}>
                {newsletterLoading ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Heart className="h-4 w-4 mr-2" />
                )}
                Subscrever
              </Button>
              <p className="text-xs text-muted-foreground/60">
                Ao subscrever, aceita a nossa <a href="/privacy" className="hover:underline">Política de Privacidade</a>.
              </p>
            </form>
          </div>
        </div>

        {/* Install App Banner */}
        {showInstall && (
          <div className="mt-10 p-6 rounded-2xl bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20 text-center">
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Smartphone className="h-6 w-6 text-primary" />
                </div>
                <div className="text-left">
                  <p className="font-serif font-semibold text-foreground">Instale a nossa App</p>
                  <p className="text-sm text-muted-foreground">Acesso rápido direto do seu telemóvel</p>
                </div>
              </div>
              {isInstallable ? (
                <Button onClick={installApp} className="rounded-full bg-primary hover:bg-primary-hover gap-2">
                  <Download className="h-4 w-4" />
                  Instalar App
                </Button>
              ) : (
                <div className="text-sm text-muted-foreground">
                  <p>No Safari, toque em <strong>Partilhar</strong> → <strong>Ecrã inicial</strong></p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Bottom bar */}
        <div className="mt-14 pt-8 border-t border-craft/20">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm text-muted-foreground flex items-center gap-2">
              © {new Date().getFullYear()} Fio & Alma Studio 
              <span className="text-primary">♥</span>
              Feito à mão em Portugal
            </p>
            <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
              <Link to="/privacy" className="text-muted-foreground hover:text-primary transition-colors">
                Privacidade
              </Link>
              <Link to="/terms" className="text-muted-foreground hover:text-primary transition-colors">
                Termos
              </Link>
              <Link to="/returns" className="text-muted-foreground hover:text-primary transition-colors">
                Devoluções
              </Link>
              <Link to="/contact" className="text-muted-foreground hover:text-primary transition-colors">
                Contacto
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
