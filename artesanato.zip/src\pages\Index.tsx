import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { HeroSection } from '@/components/home/HeroSection';
import { FeaturedProducts } from '@/components/home/FeaturedProducts';
import { CategorySection } from '@/components/home/CategorySection';
import { PromoSection } from '@/components/home/PromoSection';
import { AnnouncementsSection } from '@/components/home/AnnouncementsSection';
import { NewsSection } from '@/components/home/NewsSection';
import { ThemeBanner } from '@/components/home/ThemeBanner';
import { SEOHead } from '@/components/SEOHead';
import { useProducts, useCategories } from '@/hooks/useProducts';
import { Link } from 'react-router-dom';

const mainCraftCategories = [
  'Arranjos florais',
  'Bijuteria',
  'Bordados',
  'Ceramica',
  'Costura criativa',
  'Croche',
  'Pinturas em tecido',
  'Tricot',
  'Diversos',
];

const Index = () => {
  const { data: products = [], isLoading: productsLoading } = useProducts();
  const { data: categories = [], isLoading: categoriesLoading } = useCategories();

  return (
    <Layout>
      <SEOHead
        title="Fio e Alma Studio | Loja Online de Artesanato Feito a Mao"
        description="Descubra pecas unicas de artesanato feitas a mao: bordados, ceramica, croche, bijuteria e muito mais. Compre online na Fio e Alma Studio."
        canonical="https://fioealma.pt/"
        structuredData={{
          '@context': 'https://schema.org',
          '@type': 'Store',
          name: 'Fio e Alma Studio',
          url: 'https://fioealma.pt/',
          description: 'Loja online de artesanato feito a mao com varias categorias.',
          knowsAbout: mainCraftCategories,
          hasOfferCatalog: {
            '@type': 'OfferCatalog',
            name: 'Categorias de Artesanato',
            itemListElement: mainCraftCategories.map((category) => ({
              '@type': 'OfferCatalog',
              name: category,
            })),
          },
        }}
      />
      <AnnouncementsSection />
      <ThemeBanner />
      <HeroSection />
      <FeaturedProducts products={products} isLoading={productsLoading} />
      <CategorySection categories={categories} isLoading={categoriesLoading} />

      <section className="py-12 bg-muted/20 border-y border-border/50">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground">
              Pecas unicas, feitas a mao com amor
            </h2>
            <p className="mt-2 text-lg text-muted-foreground">Costura Artesanal</p>
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {mainCraftCategories.map((category) => (
                <Link
                  key={category}
                  to="/categories"
                  className="px-3 py-1.5 rounded-full border border-primary/25 bg-background text-sm text-foreground hover:border-primary hover:text-primary transition-colors"
                >
                  {category}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      <PromoSection />
      <NewsSection />
      
      {/* Trust section - Artisanal */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="text-center mb-14">
            <p className="text-craft font-medium mb-2">✿ O Nosso Compromisso ✿</p>
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground">
              Porquê Escolher-nos?
            </h2>
            <div className="stitch-divider w-24 mx-auto mt-4" />
          </div>
          
          <div className="grid md:grid-cols-3 gap-10">
            {[
              {
                icon: '🧵',
                title: 'Fio de Qualidade',
                description: 'Utilizamos apenas materiais premium, selecionados à mão para garantir durabilidade.',
              },
              {
                icon: '✋',
                title: '100% Artesanal',
                description: 'Cada peça é costurada à mão, com atenção a cada ponto e detalhe.',
              },
              {
                icon: '💕',
                title: 'Feito com Amor',
                description: 'Duas artesãs dedicadas, unidas pela paixão da costura tradicional.',
              },
            ].map((feature, i) => (
              <div 
                key={i} 
                className="text-center p-8 rounded-3xl bg-card border border-craft/20 hover:shadow-lg hover:border-primary/30 transition-all duration-500 group"
              >
                <div className="text-5xl mb-5 group-hover:scale-110 transition-transform duration-300">{feature.icon}</div>
                <h3 className="font-serif font-semibold text-xl mb-3 text-foreground">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
